from setuptools import setup

setup(
  name = 'really-cool-script', # This is the name of our PyPI package
  version = '0.1',              # Update the version number for new releases
  scripts = ['henloworld']      # The name of our scripts, plus the command for calling it(?)
)
